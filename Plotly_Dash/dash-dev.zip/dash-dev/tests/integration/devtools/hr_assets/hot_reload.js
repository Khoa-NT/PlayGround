
window.cheese = 'roquefort';
