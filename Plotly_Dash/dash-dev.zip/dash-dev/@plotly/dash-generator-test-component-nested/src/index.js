import MyNestedComponent from './components/MyNestedComponent';

export {
    MyNestedComponent,
};
